# import argparse
import copy
import numpy as np
import os
import sys
from test_tube import HyperOptArgumentParser
import time
import torch
import yaml

from daart.data import DataGenerator
from daart.eval import plot_training_curves
from daart.io import export_expt_info_to_csv
from daart.io import export_hparams
from daart.io import find_experiment
from daart.io import get_expt_dir
from daart.io import get_model_dir
from daart.io import get_subdirs
from daart.models import Segmenter
from daart.transforms import ZScore


def run_main(hparams, *args):
    if not isinstance(hparams, dict):
        hparams = vars(hparams)

    for key, val in hparams.items():
        print('{}: {}'.format(key, val))

    # create test-tube experiment
    hparams['expt_ids'] = hparams['expt_ids'].split(';')
    hparams = create_tt_experiment(hparams)
    if hparams is None:
        print('Experiment exists! Aborting fit')
        return

    # where model results will be saved
    model_save_path = hparams['tt_version_dir']

    # -------------------------------------
    # build data generator
    # -------------------------------------
    signals = []
    transforms = []
    paths = []

    for expt_id in hparams['expt_ids']:

        # DLC markers
        markers_file = os.path.join(hparams['data_dir'], 'markers', expt_id + '_labeled.h5')
        if not os.path.exists(markers_file):
            markers_file = os.path.join(hparams['data_dir'], 'markers', expt_id + '_labeled.csv')

        # heuristic labels
        labels_file = os.path.join(
            hparams['data_dir'], 'segmentation', 'states-v3',
            expt_id + '_beh-states-heuristic.pkl')

        # hand labels
        hand_labels_file = os.path.join(
            hparams['data_dir'], 'labels_deepethogram', 'DATA', expt_id, expt_id + '_labels.csv')

        # define data generator signals
        signals.append(['markers', 'labels_weak', 'labels_strong'])
        transforms.append([ZScore(), None, None])
        paths.append([markers_file, labels_file, hand_labels_file])

    # build data generator
    data_gen = DataGenerator(
        hparams['expt_ids'], signals, transforms, paths, device=hparams['device'],
        batch_size=hparams['batch_size'], trial_splits=hparams['trial_splits'],
        train_frac=hparams['train_frac'])
    print(data_gen)

    # -------------------------------------
    # build model
    # -------------------------------------
    hparams['rng_seed_model'] = hparams['rng_seed_train']  # TODO: get rid of this
    torch.manual_seed(hparams.get('rng_seed_model', 0))
    model = Segmenter(hparams)
    model.to(hparams['device'])
    print(model)

    # -------------------------------------
    # train model
    # -------------------------------------
    t_beg = time.time()
    model.fit(data_gen, save_path=model_save_path, **hparams)
    t_end = time.time()
    print('Fit time: %.1f sec' % (t_end - t_beg))

    # update hparams upon successful training
    hparams['training_completed'] = True
    export_hparams(hparams)


def create_tt_experiment(hparams):
    """Create test-tube experiment for organizing model fits.

    Parameters
    ----------
    hparams : dict
        dictionary of hyperparameters defining experiment

    Returns
    -------
    tuple
        - if experiment defined by hparams already exists, returns `(None, None)`
        - if experiment does not exist, returns `(hparams, exp)`

    """

    # get model path
    hparams['expt_dir'] = get_expt_dir(hparams['results_dir'], hparams['expt_ids'])
    if not os.path.isdir(hparams['expt_dir']):
        os.makedirs(hparams['expt_dir'])
        export_expt_info_to_csv(hparams['expt_dir'], hparams['expt_ids'])
    hparams['model_dir'] = get_model_dir(hparams['expt_dir'], hparams)
    tt_expt_dir = os.path.join(hparams['model_dir'], hparams['tt_experiment_name'])
    if not os.path.isdir(tt_expt_dir):
        os.makedirs(tt_expt_dir)

    # check to see if experiment already exists
    if find_experiment(hparams) is not None:
        return None

    hparams['version'] = 0
    hparams['tt_version_dir'] = os.path.join(tt_expt_dir, 'version_%i' % hparams['version'])

    return hparams


if __name__ == '__main__':

    """To run:

    (daart) $: python run_segmentation_nott.py

    """

    hp = {
        'data_config': '/home/mattw/.daart/data.yaml',
        'model_config': '/home/mattw/.daart/model.yaml',
        'train_config': '/home/mattw/.daart/train.yaml',
        'input_size': 16,
        'output_size': 5,
        'expt_ids': '2019_06_26_fly2;2019_06_26_fly2;2019_06_26_fly2;2019_06_26_fly2',
        # 'expt_ids': '2019_06_26_fly2',
        'data_dir': '/media/mattw/fly/behavior/',
        'results_dir': '/media/mattw/fly/behavior/classifiers',
        'model_type': 'lstm',
        'bidirectional': True,
        'n_hid_layers': 2,
        'n_hid_units': 32,
        'n_lags': 16,
        'activation': 'tanh',
        'lambda_weak': 1,
        'lambda_strong': 1,
        'lambda_pred': 1,
        'tt_experiment_name': 'time-test',
        'rng_seed_model': 0,
        'learning_rate': 0.0001,
        'batch_size': 2000,
        'l2_reg': 0,
        'min_epochs': 10,
        'max_epochs': 10,
        'val_check_interval': 1,
        'enable_early_stop': False,
        'early_stop_history': 20,
        'save_last_model': False,
        'train_frac': 1,
        'trial_splits': '9;1;0;0',
        'rng_seed_train': 0,
        'plot_train_curves': False,
        'device': 'cuda',
        'gpus_vis': 0,
        'tt_n_cpu_trials': 1000,
        'tt_n_cpu_workers': 5,
        'hpc_exp_number': None}

    run_main(hp)
