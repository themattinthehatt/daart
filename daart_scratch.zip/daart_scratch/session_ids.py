"""Hard-coded experiment combinations for training/testing daart models."""

# test ids that are not used for testing
EXPT_IDS_TEST = [
    '2019_06_26_fly2',
    '2019_08_14_fly1',
    '2019_08_20_fly3',
    '2019_10_14_fly2',
    '2019_10_21_fly1',
]

# 5 combinations of 2 ids for training (1 with all labels, 1 with missing labels)
EXPT_IDS_TRAIN_2 = [
    ['2019_07_01_fly2', '2019_08_08_fly1_1'],
    ['2019_08_20_fly2', '2019_06_30_fly1'],
    ['2019_10_10_fly3', '2019_08_07_fly2'],
    ['2019_10_14_fly3', '2019_08_08_fly1'],
    ['2019_10_18_fly3', '2019_08_13_fly3']
]

# 5 combinations of 4 ids for training (2 with all labels, 2 with missing labels)
EXPT_IDS_TRAIN_4 = [
    ['2019_07_01_fly2', '2019_10_18_fly3', '2019_08_08_fly1', '2019_08_07_fly2'],
    ['2019_08_20_fly2', '2019_07_01_fly2', '2019_08_13_fly3', '2019_08_08_fly1'],
    ['2019_10_10_fly3', '2019_08_20_fly2', '2019_08_08_fly1_1', '2019_06_30_fly1'],
    ['2019_10_14_fly3', '2019_10_10_fly3', '2019_06_30_fly1', '2019_08_08_fly1_1'],
    ['2019_10_18_fly3', '2019_10_14_fly3', '2019_08_07_fly2', '2019_08_13_fly3']
]

# 5 combinations of 6 ids for training (3 with all labels, 3 with missing labels)
EXPT_IDS_TRAIN_6 = [
    ['2019_06_30_fly1', '2019_08_08_fly1_1', '2019_08_13_fly3', '2019_08_20_fly2',
     '2019_10_10_fly3', '2019_10_14_fly3'],

    ['2019_06_30_fly1', '2019_08_07_fly2', '2019_08_08_fly1_1', '2019_10_10_fly3',
     '2019_10_14_fly3', '2019_10_18_fly3'],

    ['2019_07_01_fly2', '2019_08_07_fly2', '2019_08_08_fly1', '2019_08_13_fly3',
     '2019_10_14_fly3', '2019_10_18_fly3'],

    ['2019_07_01_fly2', '2019_08_07_fly2', '2019_08_08_fly1', '2019_08_13_fly3',
     '2019_08_20_fly2', '2019_10_18_fly3'],

    ['2019_06_30_fly1', '2019_07_01_fly2', '2019_08_08_fly1', '2019_08_08_fly1_1',
     '2019_08_20_fly2', '2019_10_10_fly3']
]

# 5 combinations of 8 ids for training (4 with all labels, 4 with missing labels)
EXPT_IDS_TRAIN_8 = [
    ['2019_06_30_fly1', '2019_08_07_fly2', '2019_08_08_fly1', '2019_08_13_fly3',
     '2019_08_20_fly2', '2019_10_10_fly3', '2019_10_14_fly3', '2019_10_18_fly3'],

    ['2019_07_01_fly2', '2019_08_07_fly2', '2019_08_08_fly1', '2019_08_08_fly1_1',
     '2019_08_13_fly3', '2019_10_10_fly3', '2019_10_14_fly3', '2019_10_18_fly3'],

    ['2019_06_30_fly1', '2019_07_01_fly2', '2019_08_08_fly1', '2019_08_08_fly1_1',
     '2019_08_13_fly3', '2019_08_20_fly2', '2019_10_14_fly3', '2019_10_18_fly3'],

    ['2019_06_30_fly1', '2019_07_01_fly2', '2019_08_07_fly2', '2019_08_08_fly1_1',
     '2019_08_13_fly3', '2019_08_20_fly2', '2019_10_10_fly3', '2019_10_18_fly3'],

    ['2019_06_30_fly1', '2019_07_01_fly2', '2019_08_07_fly2', '2019_08_08_fly1',
     '2019_08_08_fly1_1', '2019_08_20_fly2', '2019_10_10_fly3', '2019_10_14_fly3']
]

# 5 ids for training
EXPT_IDS_TRAIN_5 = [[
    '2019_08_07_fly2',
    '2019_08_08_fly1',
    '2019_08_20_fly2',
    '2019_10_10_fly3',
    '2019_10_14_fly3',
]]

# 10 ids for training
EXPT_IDS_TRAIN_10 = [[
    '2019_06_30_fly1',
    '2019_07_01_fly2',
    '2019_08_07_fly2',
    '2019_08_08_fly1',
    '2019_08_08_fly1_1',
    '2019_08_13_fly3',
    '2019_08_20_fly2',
    '2019_10_10_fly3',
    '2019_10_14_fly3',
    '2019_10_18_fly3',
]]

# all combinations
EXPT_IDS_TRAIN = \
    EXPT_IDS_TRAIN_2 + EXPT_IDS_TRAIN_4 + EXPT_IDS_TRAIN_6 + EXPT_IDS_TRAIN_8 + EXPT_IDS_TRAIN_10
