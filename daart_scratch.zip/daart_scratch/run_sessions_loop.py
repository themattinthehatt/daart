import os
import subprocess
import argparse
import shutil
import yaml

from daart_scratch.session_ids import EXPT_IDS_TRAIN_5, EXPT_IDS_TRAIN_10

if os.uname().nodename == 'white-noise':
    code_dir = '/home/mattw/Dropbox/github/daart'
    config_dir = '/home/mattw/.daart'
    grid_search_file = '/home/mattw/Dropbox/github/daart/daart_scratch/run_segmentation.py'
else:
    raise NotImplementedError

EXPT_IDS_LIST = EXPT_IDS_TRAIN_5

# EXPT_IDS_LIST = [['2019_06_26_fly2']]

# EXPT_IDS_LIST = [['2019_07_01_fly2', '2019_10_18_fly3', '2019_08_08_fly1', '2019_08_07_fly2']]

# EXPT_IDS_LIST = [
    # ['2019_06_26_fly2'],
    # ['2019_08_14_fly1'],
    # ['2019_10_21_fly1'],
    # ['2019_06_26_fly2', '2019_08_14_fly1'],
    # ['2019_06_26_fly2', '2019_10_21_fly1'],
    # ['2019_08_14_fly1', '2019_10_21_fly1'],
    # ['2019_06_26_fly2', '2019_08_14_fly1', '2019_10_21_fly1'],
# ]


def run_main(args):

    config_files = {
        'data': os.path.join(config_dir, 'data.yaml'),
        'model': os.path.join(config_dir, 'model.yaml'),
        'train': os.path.join(config_dir, 'train.yaml')
    }

    # create temporary config files (will be updated each iteration, then deleted)
    configs_to_update = ['data', 'model', 'train']
    for config in configs_to_update:
        dirname = os.path.dirname(config_files[config])
        filename = os.path.basename(config_files[config]).split('.')[0]
        tmp_file = os.path.join(dirname, filename + '_tmp.yaml')
        shutil.copy(config_files[config], tmp_file)
        config_files[config] = tmp_file

    # get list of models
    model_types = []
    if args.fit_mlp:
        model_types.append('temporal-mlp')
    if args.fit_lstm:
        model_types.append('lstm')
    if args.fit_gru:
        model_types.append('gru')
    if args.fit_tcn:
        model_types.append('tcn')
    if args.fit_dtcn:
        model_types.append('dtcn')

    for model_type in model_types:

        for expt_ids in EXPT_IDS_LIST:

            # modify configs
            update_config(config_files['model'], 'model_type', model_type)
            update_config(config_files['data'], 'expt_ids', expt_ids)

            call_str = [
                'python',
                grid_search_file,
                '--data_config', config_files['data'],
                '--model_config', config_files['model'],
                '--train_config', config_files['train']
            ]
            subprocess.call(' '.join(call_str), shell=True)

    for config in configs_to_update:
        os.remove(config_files[config])


def update_config(file, key, value):

    # load yaml file as dict
    config = yaml.safe_load(open(file))

    # update value
    config[key] = value

    # resave file
    with open(file, 'w') as f:
        yaml.dump(config, f)


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--fit_mlp', action='store_true', default=False)
    parser.add_argument('--fit_lstm', action='store_true', default=False)
    parser.add_argument('--fit_gru', action='store_true', default=False)
    parser.add_argument('--fit_tcn', action='store_true', default=False)
    parser.add_argument('--fit_dtcn', action='store_true', default=False)
    namespace, _ = parser.parse_known_args()
    run_main(namespace)
